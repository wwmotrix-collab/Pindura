Pindura compilado a partir de 3 versões:
1. PenduraOnline--main: base maior/estrutura completa.
2. pindura-cores-atualizadas: visual, CSS, ícones e estrutura atualizada.
3. pendura-calendar-fix: app.js e js/modules/calendar.js com calendário defensivo.

Ajustes aplicados:
- Removido FullCalendar externo não utilizado.
- Incluído js/modules/calendar.js antes de js/app.js no index.html.
- Removido js/calendar.js duplicado da raiz de js.
- vercel.json simplificado sem header global nosniff.

Substitua os arquivos do repositório pelos arquivos deste pacote.
